package DLListProject;

public interface Iterable<T> {
// @return an iterator for a collection of objects of type T
Iterator<T> iterator();
}
